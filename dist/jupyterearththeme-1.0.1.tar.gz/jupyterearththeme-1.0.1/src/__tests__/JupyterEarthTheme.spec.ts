/**
 * Example of [Jest](https://jestjs.io/docs/getting-started) unit tests
 */

describe('JupyterEarthTheme', () => {
  it('should be tested', () => {
    expect(1 + 1).toEqual(2);
  });
});
